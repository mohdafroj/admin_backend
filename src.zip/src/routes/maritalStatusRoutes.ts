import express from "express";
import maritalStatusController from "../controllers/maritalStatus/maritalStatus.controller";

const router = express.Router();

router
  .route('/createMaritalStatus')
  .post(maritalStatusController.createMaritalStatus);

router
  .route('/getMaritalStatus/:id')
  .get(maritalStatusController.getMaritalStatusById);

router
  .route('/getAllMaritalStatuses')
  .post(maritalStatusController.getAllMaritalStatuses);

router
  .route('/editMaritalStatus/:id')
  .put(maritalStatusController.editMaritalStatus);

router
  .route('/delMaritalStatus/:id')
  .put(maritalStatusController.deleteMaritalStatus);

export default router;