import { Router } from "express"
import UserMgmt from "../controllers/UserMgmt"

class UserMgmtRoutes {
  router = Router()
  userMgmt = new UserMgmt()

  constructor() {
    this.intializeRoutes()
  }
  intializeRoutes() {
    this.router.route("/add_centre_cordinator").post(this.userMgmt.createCordinatorSupervisorUser)
    this.router.route("/update_centre_cordinator").put(this.userMgmt.updateCordinatorSupervisorUser)
    this.router
      .route("/delete_centre_cordinator")
      .patch(this.userMgmt.deleteCordinatorSupervisorUser)
    this.router.route("/add_venue_supervisor").post(this.userMgmt.createVenueSupervisorUser)
    this.router.route("/update_venue_supervisor").put(this.userMgmt.updateVenueSupervisorUser)
    this.router.route("/delete_venue_supervisor").patch(this.userMgmt.deleteVenueSupervisorUser)
    this.router.route("/:id").get(this.userMgmt.getUserByUUId)
    this.router.route("/login").post(this.userMgmt.login)
  }
}
export default new UserMgmtRoutes().router
