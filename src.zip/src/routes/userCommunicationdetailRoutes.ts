import { Router } from "express"
import express from 'express';
import GetMasterData from "../controllers/GetMasterData"
import {userCommunicationDetailController} from "../controllers/"

const router = express.Router();

router
  .route('/createUserCommunicationDetail')
  .post(userCommunicationDetailController.createUserCommunicationDetail);

  router
  .route('/getUserCommunicationDetail/:id')
  .get(userCommunicationDetailController.getUserCommunicationDetailById);

  router
  .route('/getAllUserCommunicationDetail')
  .post(userCommunicationDetailController.getAllUserCommunicationDetail);

  router
  .route('/editUserCommunicationDetail/:id')
  .put(userCommunicationDetailController.editUserCommunicationDetail);

  router
  .route('/delUserCommunicationDetail/:id')
  .put(userCommunicationDetailController.deleteUserCommunicationDetail);

export default router;