import { Router } from "express"
import express from 'express';
import GetMasterData from "../controllers/GetMasterData"
import {mdmMasterController} from "../controllers/"

const router = express.Router();

router
  .route('/createMdmMaster')
  .post(mdmMasterController.createMdm);

  router
  .route('/getMdmMaster/:id')
  .get(mdmMasterController.getMdmById);

  router
  .route('/getAllMdmMaster')
  .get(mdmMasterController.getAllMdms);

  router
  .route('/editMdmMaster/:id')
  .put(mdmMasterController.updateMdm);

  router
  .route('/editMdmMasterCountry/:id')
  .put(mdmMasterController.updateMdmCountry);

  router
  .route('/addMdmCountry/:id')
  .put(mdmMasterController.addMdmCountry);


export default router;
