import { Router } from "express"
import GetMasterData from "../controllers/GetMasterData"
import validate from '../middlewares/validate'
import {getmastervalidation} from '../../src/validations'

class GetMasterDataRoutes {
  router = Router()
  getMasterData = new GetMasterData()

  constructor() {
    this.intializeRoutes()
  }
  intializeRoutes() {
    this.router.route("/designations").get(this.getMasterData.getAllDesignation)
    this.router.route("/roles").get(this.getMasterData.getAllRoles)
    this.router.route("/departments").get(this.getMasterData.getAllDepartments)
    this.router.route("/officer_types").get(this.getMasterData.getAllOfficerTypes)
    this.router.route("/user_types").get(this.getMasterData.getAllUserTypes)
    this.router.route("/auditlogs").get(this.getMasterData.getAllAuditlog)
    this.router.route("/auditsearchlogs").post(this.getMasterData.getAllAuditSearchlog)
    this.router.route("/candidateDetails").post(this.getMasterData.getAllCandidate)
    this.router.route("/summary").post(this.getMasterData.summary)
    this.router.route("/candidateCount").get(this.getMasterData.CandidateCount)
    this.router.route("/otrDetail").post(this.getMasterData.otrDetail)
    this.router.route("/otpLog").post(this.getMasterData.otpLog)
    this.router.route("/otpTempLog").post(validate(getmastervalidation.createCandidate),this.getMasterData.otrTempLog)
    this.router.route("/countDocumentotrTempLogs").get(this.getMasterData.countDocumentotrTempLogs)
    this.router.route("/login").post(this.getMasterData.loginUser)
  }
}
export default new GetMasterDataRoutes().router
