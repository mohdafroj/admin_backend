import MdmMasterModel, {
  PaginationOptions,
  IMdmMaster,
} from "../../models/mdmMaster.model";

const createMdm = async (mdmData: IMdmMaster) => {
  try {
    const newMdm = new MdmMasterModel(mdmData);
    await newMdm.save();
    return { success: true, data: newMdm };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};

const getAllMdms = async () => {
  try {
    const mdms = await MdmMasterModel.find();
    return { success: true, data: mdms };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};

const getMdmById = async (id: string) => {
  try {
   
    const mdm = await MdmMasterModel.findOne({ masterId: id });
   
    return mdm
      ? { success: true, data: mdm }
      : { success: false, error: "MDM not found" };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};

const updateMdm = async (id: string, updateData: Partial<IMdmMaster>) => {
  try {
   const updatedMdm = await MdmMasterModel.findByIdAndUpdate(id, updateData, {
      new: true,
    });
    return updatedMdm
      ? { success: true, data: updatedMdm }
      : { success: false, error: "MDM not found" };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
const updateMdmCountry = async (
  masterId: string,
  countryId: string,
  updateData: any
) => {
  try {
    const filter = { masterId: masterId, "data.countryId": countryId };
    const update = {
      $set: {
        "data.$.countryNameEn": updateData.countryNameEn,
      },
    };
    if (masterId == "") {
      return { success: false, error: "Master Id should not be blank" };
    }
    if (countryId == "") {
      return { success: false, error: "Country Id should not be blank" };
    }

    const updatedMdm = await MdmMasterModel.updateOne(filter, update);
    
    if (updatedMdm.modifiedCount == 0) {
      return { success: false, error: "Record Not exist" };
    }
    return updatedMdm
      ? { success: true, data: updatedMdm }
      : { success: false, error: "MDM not found" };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
const addMdmCountry = async (
  masterId: string,
  updateData: any
) => {
  try {
    const filter = { masterId: masterId};
    //code for total record
    const result = await MdmMasterModel.aggregate([
      { $match: { masterId: masterId } }, // Match the document by masterId
      { $project: { dataCount: { $size: "$data" } } } // Count elements in the `data` array
  ]);

  if (result.length > 0) {
      console.log(`Number of elements in the data array: ${result[0].dataCount}`);
  } else {
      console.log('No document found with the given masterId.');
  }
    //code for total record
   const adddata =  { countryId: result[0].dataCount+1, 
    countryNameEn: updateData.countryNameEn,
        "countryNameHi": updateData.countryNameEn,
        "countryNationality": updateData.countryNationality,
        "isActive": "Y",
        "createdBy": 1,
        "createdDt": Date(),
        "modifiedBy": 1,
        "modifiedDt": Date(),
        "recordVersion": 1};
   
    if (masterId == "") {
      return { success: false, error: "Master Id should not be blank" };
    }
   

    const updatedMdm = await MdmMasterModel.updateOne(filter,  { $push: { data: adddata } } );
    
    if (updatedMdm.modifiedCount == 0) {
      return { success: false, error: "Record Not exist" };
    }
    return updatedMdm
      ? { success: true, data: updatedMdm }
      : { success: false, error: "MDM not found" };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};

const deleteMdm = async (id: string) => {
  try {
    const deletedMdm = await MdmMasterModel.findByIdAndDelete(id);
    return deletedMdm
      ? { success: true, data: deletedMdm }
      : { success: false, error: "Mdm not found" };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
export default {
  createMdm,
  getMdmById,
  getAllMdms,
  updateMdm,
  deleteMdm,
  updateMdmCountry,
  addMdmCountry,
};
