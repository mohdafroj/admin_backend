/*-------------------------------------------------------------------------------\
| Title : UserCommunicationdetail Services                                                           |
+--------------------------------------------------------------------------------+
| Repository: 2024 (CIPL) Company                                                |
+--------------------------------------------------------------------------------+
| This module was programmed by userCommunicationdetail master api                                           |
+--------------------------------------------------------------------------------|
| Version 1.0 :-                                                                 |
+--------------------------------------------------------------------------------+
| CODE DESCRIPTION :   UserCommunicationdetail Services                                                         |
|                                                                                |
+--------------------------------------------------------------------------------+
| NOTES :-  UserCommunicationdetail Services crud operation                                                  |
| _____                                                                          |
|                                                                                |
\-------------------------------------------------------------------------------*/
import UserCommunicationdetail , { PaginationOptions } from "../../models/userCommunicationDetail.model"

/**
 * Create a menu
 * @param {Object} userCommunicationdetailBody
 * @returns {Promise<Cmm>}
 */

const createUserCommunicationdetailTemp = async (logData: any): Promise<any> => {
  try {
    
    let userCommunicationdetail = new UserCommunicationdetail(logData);
    await userCommunicationdetail.save();

    return {
      error: false,
      data: userCommunicationdetail,
      msg: 'new userCommunicationdetail is created'
    };
  } catch (error: any) {
    return {
      error: true,
      msg: error?.message || 'An error occurred'
    };
  }
};

/**
 * Get a role by menuId
 * @param {number} id
 * @returns {Promise<UserCommunicationdetail | null>}
 */
const getUserCommunicationdetailById = async (id: number): Promise<any> => {
  try {
    const userCommunicationdetail = await UserCommunicationdetail.findOne({ userCommunicationdetailId: id });
    return userCommunicationdetail;
  } catch (error: any) {
    throw new Error('Error fetching userCommunicationdetail');
  }
};


/**
 * Get all menus
 * @returns {Promise<any[]>}
 */

// Method to get the total count of menus matching the query
const getUserCommunicationdetailCount = async (query: any) => {
  try {
    return await UserCommunicationdetail.countDocuments(query);
  } catch (error) {
    throw new Error('Error fetching userCommunicationdetail count');
  }
};
const getAllUserCommunicationdetails = async (options: PaginationOptions, query: any = {}) => {
  const { page, limit } = options;
  const skip = (page - 1) * limit;
  
  try {
    const userCommunicationdetails = await UserCommunicationdetail.find(query)
      .skip(skip)
      .limit(limit)
      .exec();
    
    return userCommunicationdetails;
  } catch (error) {
    throw new Error('Error fetching userCommunicationdetails');
  }
};


/**
 * Edit a userCommunicationdetail by userCommunicationdetailId
 * @param {number} id
 * @param {Partial<UserCommunicationdetail>} userCommunicationdetailBody
 * @returns {Promise<UserCommunicationdetail | null>}
 */
const editUserCommunicationdetail = async (id: number, userCommunicationdetailBody: Partial<any>): Promise<{ error: boolean, data: any, msg: string }> => {
  try {
    const updatedUserCommunicationdetail = await UserCommunicationdetail.findOneAndUpdate(
      { userCommunicationdetailId: id },
      { $set: userCommunicationdetailBody },
      { new: true } 
    ).exec();
    return {
      error: false,
      data: updatedUserCommunicationdetail,
      msg: 'UserCommunicationdetail Edited successfully'
    };

  } catch (error: any) {
    throw new Error('Error updating userCommunicationdetail');
  }
};

/**
 * Delete a role by userCommunicationdetailId (set isActive to 'N')
 * @param {number} id
 * @returns {Promise<UserCommunicationdetail | null>}
 */
const deleteUserCommunicationdetail = async (id: number): Promise<{ error: boolean, data: any, msg: string }> => {
  try {
    const deletedUserCommunicationdetail = await UserCommunicationdetail.findOneAndUpdate(
      { userCommunicationdetailId: id },
      { $set: { isActive: 'N' } }, 
      { new: true } 
    ).exec();
    return {
      error: false,
      data: deletedUserCommunicationdetail,
      msg: 'UserCommunicationdetail inactivate successfully'
    };
  } catch (error: any) {
    throw new Error('Error deleting userCommunicationdetail');
  }
};

const getLastUserCommunicationdetail = async (): Promise<any> => {
  return await UserCommunicationdetail.find().sort({_id:-1}).limit(1);
};


export default {
  createUserCommunicationdetailTemp,
  getUserCommunicationdetailById,
  getAllUserCommunicationdetails,
  editUserCommunicationdetail,
  deleteUserCommunicationdetail,
  getLastUserCommunicationdetail,
  getUserCommunicationdetailCount
};
