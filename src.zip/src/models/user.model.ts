/* eslint-disable prettier/prettier */
/*-------------------------------------------------------------------------------\
| Title : User  Model                                                          |
+--------------------------------------------------------------------------------+
| Repository: 2024 (CIPL) Company                                                |
+--------------------------------------------------------------------------------+
| This module was programmed by User Model field                                        |
+--------------------------------------------------------------------------------|
| Version 1.0 :-                                                                 |
+--------------------------------------------------------------------------------+
| CODE DESCRIPTION :   User model                                                        |
|                                                                                |
+--------------------------------------------------------------------------------+
| NOTES :-  User model                                                 |
| _____                                                                          |
|                                                                                |
\-------------------------------------------------------------------------------*/
import mongoose, { Document, Model, Schema } from "mongoose";
import { adminDB } from "../db/connect"
import { v4 as uuidv4 } from 'uuid'; // Import uuid for generating unique IDs
export interface IUser extends Document {
  userId: Number;
  userUuId: String;
  userNameEn: String;
  userNameHi: String;
  employeeCode: String;
  departmentId: Number;
  designationId: Number;
  officerTypeId: Number;
  userTypeId: Number;
  dateOfBirth: String;
  dateOfJoining: String;
  dateOfRetirement: String;
  deActivationLoginDate: String;
  password: String;
  phoneNumber: String;
  emailId: String;
  aadharRefId: String;
  userPhoto: String;
  userSignature: String;
  EmpDigitalSignatureFlag: String;
  Emp_DigitalSignatureId: String;
  isActive: String;
  createdBy: String;
  modifiedBy: String;
  recordVersion: String;
  auditLogId: Number;
}
export interface PaginationOptions {
  page: number;
  limit: number;
}
const UserSchema: Schema = new Schema(
  {
    userId: {
      type: Number,
    },
    userUuId: {
      type: String,
      unique: true,
      default: () => uuidv4().replace(/-/g, ''), // Generate a unique UUID and remove dashes
    },
    userNameEn: {
      type: String,
      unique: true,
      required: [true, "user name (English) is required"],
      match: [/^[A-Za-z\s]+$/, 'User name (English) should only contain alphabetic characters and spaces'], 
    },
    userNameHi: {
      type: String,
    },
    employeeCode: {
      type: String,
    },
    departmentId: {
      type: Number,
    },
    designationId: {
      type: Number,
    },
    officerTypeId: {
      type: Number,
    },
    userTypeId: {
      type: Number,
    },
    dateOfBirth: {
      type: String,
    },
    dateOfJoining: {
      type: String,
    },
    deActivationLoginDate: {
      type: String,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      validate: {
        validator: function(v: string) {
          return v.length >= 8; // Check if password length is at least 8 characters
        },
        message: (props: any) => `${props.value} is not a valid password! Password must be at least 8 characters long.`,
      },
    },
    phoneNumber: {
      type: String,
      validate: {
        validator: function(v: string) {
          // Regular expression for validating phone number (optional)
          return /^[0-9]{10}$/.test(v);
        },
        message: (props: any) => `${props.value} is not a valid phone number!`,
      },
    },
    emailId: {
      type: String,
      required: [true, "Email ID is required"],
      unique: true,
      match: [
        /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/,
        'Please enter a valid email address'
      ],
    },
    aadharRefId: {
      type: String,
    },
    userPhoto: {
      type: String,
    },
    userSignature: {
      type: String,
    },
    EmpDigitalSignatureFlag: {
      type: String,
    },
    Emp_DigitalSignatureId: {
      type: String,
    },
    isActive: {
      type: String,
    },
    createdBy: {
      type: String,
    },
    modifiedBy: {
      type: String,
    },
    recordVersion: {
      type: String,
    },
    auditLogId: {
      type: Number,
    },
  },
  { timestamps: true }
);


const UserModel: Model<IUser> = adminDB.model<IUser>(
  "UserSchema",
  UserSchema,
  "MST_User"
)
export default UserModel;
