/* eslint-disable prettier/prettier */
/*-------------------------------------------------------------------------------\
| Title : userCommunicationdetail  Model                                                          |
+--------------------------------------------------------------------------------+
| Repository: 2024 (CIPL) Company                                                |
+--------------------------------------------------------------------------------+
| This module was programmed by userCommunicationdetail Model field                                        |
+--------------------------------------------------------------------------------|
| Version 1.0 :-                                                                 |
+--------------------------------------------------------------------------------+
| CODE DESCRIPTION :   UserCommunicationdetail model                                                        |
|                                                                                |
+--------------------------------------------------------------------------------+
| NOTES :-  userCommunicationdetail model                                                 |
| _____                                                                          |
|                                                                                |
\-------------------------------------------------------------------------------*/
import mongoose, { Document, Model, Schema, } from 'mongoose';
import { adminDB } from "../db/connect"
import { v4 as uuidv4 } from 'uuid'; // Import uuid for generating unique IDs
export interface IuserCommunicationdetail extends Document {
    userCommunicationdetailId: Number,
    userUuid: String,
    addressTypeId: String,
    countryId: String,
    stateId: String,
    districtId: String,
    districtOth: String,
    cityId: String,
    cityOth: String,
    address1: String,
    address2: String,
    pincodeId: String,
    otherPincode: String,
    isActive: String,
    createdBy: String,
    modifiedBy: String,
    recordVersion: String,
    auditLogId: Number,
}
export interface PaginationOptions {
  page: number;
  limit: number;
}
const UserCommunicationdetailSchema: Schema = new Schema(
  {
    userCommunicationdetailId: {
      type: Number,
     },
     userUuid: {
        type: String,
       },
    addressTypeId: {
      type: Number,
      
    },
    countryId: {
      type: Number,
    },
    stateId: {
        type: Number,
      },
    districtId: {
        type: Number,
      },
    districtOth: {
        type: String,
      },
    cityId: {
        type: Number,
      },
    cityOth: {
        type: String,
      },
    address1: {
        type: String,
      },
    address2: {
        type: String,
      },
    pincodeId: {
        type: Number,
      },
    otherPincode: {
        type: Number,
      },
    isActive: {
      type: String,
    },
    createdBy: {
      type: String,
    },
    modifiedBy: {
      type: String,
    },
    recordVersion: {
      type: String,
    },
    auditLogId: {
      type: Number,
    },
  },
  { timestamps: true }
);


const UserCommunicationdetailModel: Model<IuserCommunicationdetail> = adminDB.model<IuserCommunicationdetail>(
    "MST_User_Comm",
    UserCommunicationdetailSchema,
    "MST_User_Comm"
  )
export default UserCommunicationdetailModel;
