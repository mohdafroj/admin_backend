/*-------------------------------------------------------------------------------\
| Title : UserCommunicationDetails  Controller                                                           |
+--------------------------------------------------------------------------------+
| Repository: 2024 (CIPL) Company                                                |
+--------------------------------------------------------------------------------+
| This module was programmed by UserCommunicationDetails master api                                           |
+--------------------------------------------------------------------------------|
| Version 1.0 :-                                                                 |
+--------------------------------------------------------------------------------+
| CODE DESCRIPTION :   userCommunicationDetails Controller                                                          |
|                                                                                |
+--------------------------------------------------------------------------------+
| NOTES :-  UserCommunicationDetails controller crud operation                                                  |
| _____                                                                          |
|                                                                                |
\-------------------------------------------------------------------------------*/
import httpStatus from 'http-status';
import catchAsync from '../../utils/catchAsync';
import { userCommunicationdetailService } from '../../services';
import UserCommunicationDetail , { PaginationOptions } from "../../models/userCommunicationDetail.model"
//code start for creation
 const createUserCommunicationDetail = catchAsync(async (req, res) => {
  const userCommunicationDetailBody = req.body;
  
  const lastUserCommunicationDetail = await userCommunicationdetailService.getLastUserCommunicationdetail()
  userCommunicationDetailBody.userCommunicationdetailId = lastUserCommunicationDetail.length>0 ? lastUserCommunicationDetail[0].userCommunicationdetailId + 1 : 1
  const userCommunicationDetailResponse = await userCommunicationdetailService.createUserCommunicationdetailTemp(userCommunicationDetailBody);
  res.send(userCommunicationDetailResponse);
});
//code end for creation

//code start for get id wise code
const getUserCommunicationDetailById = catchAsync(async (req, res) => {

  const userCommunicationdetailId =req.params.id
  const userCommunicationDetail = await userCommunicationdetailService.getUserCommunicationdetailById(userCommunicationdetailId);
  if (!userCommunicationDetail) {
    return res.status(httpStatus.NOT_FOUND).send('userCommunicationDetail not found');
  }

  res.status(httpStatus.OK).send(userCommunicationDetail);
});
//code end for get id wise code

//code start for all record


const getAllUserCommunicationDetail = catchAsync(async (req, res) => {
const { page = 1, limit = 5, params } = req.body;
  // const{params} = req.body

  const menuNameEn = params?.menuNameEn
  const startDate = params?.startDate
  const endDate = params?.endDate
  // Validate and parse pagination parameters
  const pageNumber = parseInt(page as string, 10);
  const limitNumber = parseInt(limit as string, 10);

  if (isNaN(pageNumber) || isNaN(limitNumber) || pageNumber <= 0 || limitNumber <= 0) {
    return res.status(httpStatus.BAD_REQUEST).send('Invalid pagination parameters');
  }

  const options: PaginationOptions = {
    page: pageNumber,
    limit: limitNumber
  };

  // Build query object based on provided filters
  const query: any = {};
  if (menuNameEn) {
    query['userCommunicationDetailNameEn'] = { $regex: menuNameEn, $options: 'i' }; // Case-insensitive search using regex
  }
  if (startDate && endDate) {
    query['createdAt'] = { $gte: new Date(startDate), $lte: new Date(endDate) };
  }
console.log(query);
  const userCommunicationDetails = await userCommunicationdetailService.getAllUserCommunicationdetails(options, query);
  const totalCount = await userCommunicationdetailService.getUserCommunicationdetailCount(query);

  if (!userCommunicationDetails) {
    return res.status(httpStatus.NOT_FOUND).send('No userCommunicationDetails found');
  }

  //res.status(httpStatus.OK).send(departments,totalCount);
  res.status(httpStatus.OK).send({
    totalCount,
    currentPage: options.page,
    totalPages: Math.ceil(totalCount / options.limit),
    pageSize: options.limit,
    userCommunicationDetails
  });
});


//code end for all record
//code end for all record

// code start for edit code
const editUserCommunicationDetail = catchAsync(async (req, res) => {
  const userCommunicationDetailId = req.params.id;
  const userCommunicationDetailBody = req.body;
  const updatedUserCommunicationDetail = await userCommunicationdetailService.editUserCommunicationdetail(userCommunicationDetailId, userCommunicationDetailBody);

  if (!updatedUserCommunicationDetail) {
    return res.status(httpStatus.NOT_FOUND).send('UserCommunicationDetail not found');
  }

  res.status(httpStatus.OK).send(updatedUserCommunicationDetail);
});
// code end for edit code

//code start for delete record
const deleteUserCommunicationDetail = catchAsync(async (req, res) => {
  const userCommunicationDetailId = req.params.id;
  const deletedUserCommunicationDetail = await userCommunicationdetailService.deleteUserCommunicationdetail(userCommunicationDetailId);

  if (!deletedUserCommunicationDetail) {
    return res.status(httpStatus.NOT_FOUND).send('UserCommunicationDetail not found');
  }

  res.status(httpStatus.OK).send('UserCommunicationDetail deleted successfully');
});
//code end for delete record


export default {
  createUserCommunicationDetail,
  getUserCommunicationDetailById,
  getAllUserCommunicationDetail,
  editUserCommunicationDetail,
  deleteUserCommunicationDetail
};