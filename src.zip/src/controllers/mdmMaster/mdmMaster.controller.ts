import { Request, Response, NextFunction } from "express"
import { responseHandler } from "../../utils/responseHandler"

import { mdmMasterService} from '../../services/';
import MdmMasterModel , { PaginationOptions } from "../../models/mdmMaster.model"
 const createMdm = async (req: Request, res: Response) => {
  const result = await mdmMasterService.createMdm(req.body);
  if (result.success) {
    res.status(201).json(result);
  } else {
    res.status(400).json(result);
  }
};

 const getAllMdms = async (req: Request, res: Response) => {
  const result = await mdmMasterService.getAllMdms();
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(400).json(result);
  }
};

 const getMdmById = async (req: Request, res: Response) => {
  const result = await mdmMasterService.getMdmById(req.params.id);
  
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(404).json(result);
  }
};

 const updateMdm = async (req: Request, res: Response) => {
  const result = await mdmMasterService.updateMdm(req.params.id, req.body);
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(404).json(result);
  }
};
const updateMdmCountry = async (req: Request, res: Response) => {
 
  
  const result = await mdmMasterService.updateMdmCountry(req.body.masterId, req.body.countryId, req.body);
  
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(404).json(result);
  }
};
const addMdmCountry = async (req: Request, res: Response) => {
 
  
  const result = await mdmMasterService.addMdmCountry(req.body.masterId, req.body);
  
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(404).json(result);
  }
};

 const deleteMdm = async (req: Request, res: Response) => {
  const result = await mdmMasterService.deleteMdm(req.params.id);
  if (result.success) {
    res.status(200).json(result);
  } else {
    res.status(404).json(result);
  }
};
export default {
  createMdm,
  getMdmById,
  getAllMdms,
  updateMdm,
  deleteMdm,
  updateMdmCountry,
  addMdmCountry
};