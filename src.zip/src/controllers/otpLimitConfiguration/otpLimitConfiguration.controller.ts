/*-------------------------------------------------------------------------------\
| Title : OTPLimitConfiguration   Controller                                                           |
+--------------------------------------------------------------------------------+
| Repository: 2024 (CIPL) Company                                                |
+--------------------------------------------------------------------------------+
| This module was programmed by Otp Limit Configuration api                                           |
+--------------------------------------------------------------------------------|
| Version 1.0 :-                                                                 |
+--------------------------------------------------------------------------------+
| CODE DESCRIPTION :   Otp Limit Configuration Controller                                                          |
|                                                                                |
+--------------------------------------------------------------------------------+
| NOTES :- OTP Limit Configuration operation                                                  |
| _____                                                                          |
|                                                                                |
\-------------------------------------------------------------------------------*/
// import httpStatus from 'http-status';
// import catchAsync from '../../utils/catchAsync';
// import {createOTPLimitConfiguration} from '../../services';
// import OTPLimitConfiguration , { PaginationOptions } from "../../models/otpLimitConfiguration"
// //code start for creation
// const createOTPLimitConfiguration = catchAsync(async (req, res) => {
//   const body = req.body;
//   const logResponse = await createOTPLimitConfiguration.create(body);
//   res.send(logResponse);
// });
// //code end for creation


// export default {
//     createOTPLimitConfiguration,
// };